%% 4BM20 Assigment 
% 
% 
% Reading the image file


clc; clear all; clear figure; clear var
patern=load('Images\Labels.mat');pat=struct2table(patern);
dc = dir('Images\*.tiff');dct=struct2table(dc);
Image_table=[dct pat];%make table and concatenate the pattern tag.

ds = imageDatastore("Images\","FileExtensions",'.tiff');%read only tiff files
File=1;
df1=rdimg(File); %read 1 image file for example

img=1; % for figure


%% Q1-Q2
% Find a suitable thershold data and determine an image with black and white 
% binary value.

% histogram of image data
figure
figure(img+1)
%imhist(I) calculates the histogram for the grayscale image I. The imhist 
%function returns the histogram counts in counts and the bin locations in 
%binLocations.
subplot(1,2,1)
imhist(df1)
title('Histogram of image data')
imh1=imhist(df1);
% Do curve fitting (histfit) to the histogram line, thus we can substract edge value of the histogram
subplot(1,2,2)
hift1=histfit(imh1);
title('Curve fitting for histogram data of image')
% from the histogram, the best threshoold can be taken:
hift1_max=max(hift1(2).YData); %substract line data only, and taking the maximum value

figure
hift1_max %print out histogram fit value
threshold=round(hift1_max,-2);
df_bw =df1 > threshold;
figure(img+2)
subplot(1,2,1)
imshow(df1);title('Origin image')
subplot(1,2,2)
imshow(df_bw);title('Using selected threshold.')

%% Q3
% Load 1 file and determine the longest line of an image.


%load file
clear variables;
File_no=7;
df=rdimg(File_no);

%% 
% 1 set up strel for the mask filter

% r=4;n=8;
SE_disk = strel('disk',15,0);

%% 
% 2 use image close to filter image

imcls_plt(df,SE_disk);
title('image close')
test=(im2bw(imcls_plt(df,SE_disk)));


%% 
% 3 Hough transformation Get H, T, R and plot

[H,T,R]=hh(test);
%peaks identify
peaks_id=4;
P  = hh_lineplt(H,T,R,peaks_id);


fgp=3;mini_l=4;
lines = houghlines(test,T,R,P,'FillGap',fgp,'MinLength',mini_l);
%canvavs for origin
figure
figure(9)
imshow(df,'InitialMagnification', 800), hold on
title('Max len')
% exportgraphics(figure(9),'Q5_sq_.png',"Resolution",300)


%% 
% Return longest line of the image. 

max_len=hh_linMax(lines)
%% Q4-Q5

clear all; clear var;

%set up a disk structure mask
SE_disk = strel('disk',15,0);

%start of for loop
for i=1:length(dc)

    test =im2bw(imclose(rdimg(i),SE_disk));
    
H=0;T=0;R=0;%reset    
[H,T,R] = hough(test);
%peaks identify
peaks_id=6;
P  =houghpeaks(H,peaks_id,'threshold',ceil(0.3*max(H(:))));

fgp=3;mini_l=4;
lines=0;%reset
lines = houghlines(test,T,R,P,'FillGap',fgp,'MinLength',mini_l);

%find max line
max_len = 0;
for k = 1:length(lines)
   xy = [lines(k).point1; lines(k).point2];
   len = norm(lines(k).point1 - lines(k).point2);
   if ( len > max_len)
      max_len = len;
      xy_long = xy;
   end
end
%calculate the image area by sum all pixel
Area_of_org_img=sum(test,"all");

%0 is cirlce
%1 is square
id=max_len^2/Area_of_org_img;

if id<1.27
    t(i)=0;%circle
else
    t(i)=1;
end

end

%% 
% Determine the accuracy

Acc=0;
for i=1:length(dc)
    
    if eq(t(i),Image_table.Labels(i))
        Acc=Acc+1;
    end
end
%return accuracy
Accuracy=(Acc/1000)*100
%% 
% Function

function [max_len,Area_max_cir,Area_max_sq,Area_of_org_img]= exp_area_len(img_ps,peaks_id)
%introduce functions
    [H,T,R]=hh(img_ps);
    P  = hh_lineplt(H,T,R,peaks_id);
%     fgp=1;mini_l=2;
    lines = houghlines(test,T,R,P,'FillGap',1,'MinLength',2);
    figure, imshow(df), hold on
    
    max_len=hh_linMax(lines)
    
    % print line and area
    Area_max_cir=pi*((max_len/2)^2)
    Area_max_sq=max_len^2
    print('Area of origin')
    Area_of_org_img=sum(test,"all")
end


function [img,bimg]=rdimg(file)
    ds = imageDatastore("Images\","FileExtensions",'.tiff');
    img=imread(ds.Files{file});
    bimg=im2bw(img);
end


function dil_plt(BW,se)
figure
    subplot(1,2,1)
    BW2 = imdilate(BW,se);
    imshow(BW), title('Original')
    subplot(1,2,2)
    imshow(BW2), title('Dilated')
end

function ero_plt(BW,se)
figure
    subplot(1,2,1)
    BW2 = imerode(BW,se);
    imshow(BW), title('Original')
    subplot(1,2,2)
    imshow(im2bw(BW2)), title('erode')
end

function [BW2]= imcls_plt(BW,se)
figure
    subplot(1,2,1)
    BW2 = imclose(BW,se);
    imshow(BW), title('Original')
    subplot(1,2,2)
    imshow(BW2), title('imclose')
end

function [H,T,R]=hh(img)
%hough function is installed internal
    [H,T,R] = hough(img);
    figure
    imshow(H,[],'XData',T,'YData',R,...
                'InitialMagnification','fit');
    xlabel('\theta'), ylabel('\rho');
    axis on, axis normal, hold on;
end


function [P]=hh_lineplt(H,T,R,peaks_id)
P  = houghpeaks(H,peaks_id,'threshold',ceil(0.3*max(H(:))));
x = T(P(:,2)); y = R(P(:,1));
plot(x,y,'s','color','red');
end

function[len]= hh_linMax(lines)
max_len = 0;
for k = 1:length(lines)
   xy = [lines(k).point1; lines(k).point2];
   plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');

   % Plot beginnings and ends of lines
   plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
   plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');

   % Determine the endpoints of the longest line segment
   len = norm(lines(k).point1 - lines(k).point2);
   if ( len > max_len)
      max_len = len;
      xy_long = xy;
   end
end

plot(xy_long(:,1),xy_long(:,2),'LineWidth',2,'Color','#FF00FF');
end